node.set["postgreSQL"]={}
node.set["postgreSQL"]["allowSubnet"]=["192.168.34.0/24", "10.15.6.0/24"]
node.set["postgreSQL"]["archivedir"]='/var/lib/pgsql/9.1/archive'
node.set["master"]={}
node.set["master"]["ip"]='54.251.253.234'
node.set["master"]["port"]='5432'
node.set["master"]["user"]='postgres'
node.set["master"]["password"]='p@ssw0rd'
