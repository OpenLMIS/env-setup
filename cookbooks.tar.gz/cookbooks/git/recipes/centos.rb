# Cookbook Name:: git
# Recipe:: centos
#
# Copyright 2011
#
# All rights reserved - Do Not Redistribute

package "git"
