node.set["java"]={}
node.set["tomcat"]={}
node.set["webapp"]={}
node.set["webapp"]["home"]="/home/openlmis"
node.set["webapp"]["user"]="openlmis"
node.set["java"]["home"]="/usr/java/jdk1.7.0_09"
node.set["tomcat"]["home"]="#{node["webapp"]["home"]}/apache-tomcat-7.0.33"
