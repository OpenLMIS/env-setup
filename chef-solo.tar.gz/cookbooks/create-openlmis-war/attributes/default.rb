node.set["home"]["dir"]="/home/openlmis"
node.set["war"]["location"]="#{node['home']['dir']}/open-lmis/modules/openlmis-web/build/libs"

