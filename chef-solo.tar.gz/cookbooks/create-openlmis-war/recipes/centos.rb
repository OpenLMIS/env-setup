git "#{node['home']['dir']}" do
	repository node["app"]["repo"]
	action :checkout
	user "openlmis"
end

execute "setupdb seed testseed and create war" do
	cwd "#{node['home']['dir']}/open-lmis"
	command "gradle setupdb seed testseed war"
	action :run
	user "openlmis"
end

execute "move war to home directory" do
	command "mv #{node['war']['location']}/openlmis-web.war ROOT.war"
	cwd "#{node['home']['dir']}"
	user "openlmis"
end

execute "deploy war" do
code <<-EOH 
serivce stop tomcat
rm -rf $LMIS_SERVER_HOME/webapps/ROOT/
mkdir $LMIS_SERVER_HOME/webapps/ROOT/
cd $LMIS_SERVER_HOME/webapps/ROOT/
jar -xvf /home/openlmis/ROOT.war
sudo rm -rf /var/www/openlmis
sudo mkdir /var/www/openlmis
sudo mv public/ /var/www/openlmis/
service tomcat start
EOH

user "openlmis"
end
