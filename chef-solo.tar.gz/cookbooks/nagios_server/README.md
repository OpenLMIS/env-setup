Description
===========
Sets up Nagios Server to monitor application nodes
Requirements
============

Attributes
==========

Usage
=====

