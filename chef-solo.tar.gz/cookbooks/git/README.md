DESCRIPTION:
============
Installs package for git

REQUIREMENTS:
=============

ATTRIBUTES:
===========

USAGE:
======
