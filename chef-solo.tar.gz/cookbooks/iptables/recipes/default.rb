# Cookbook Name:: iptables
# Recipe:: default
#
# Copyright 2012
#
# All rights reserved - Do Not Redistribute

service "iptables" do
  action :stop
end
