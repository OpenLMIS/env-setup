node.set["nagios"] ||= {}
node.set["nagios"]["plugins_dir"] = "/usr/lib64/nagios/plugins"
node.set["nagios"]["admins"] = {}
node.set["nagios"]["guests"] = {}
