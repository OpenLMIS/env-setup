Description
===========
Sets up cron job to run chef-client every 30 mins

Requirements
============
chef installed on the end node during bootstrap or via cookbook

Attributes
==========
None

Usage
=====
To automate node convergence
