DESCRIPTION
===========

Installs and starts httpd
