git "#{node['home']['dir']}/open-lmis" do
	repository "#{node['app']['repo']}"
	action :checkout
	user "openlmis"
end

script "setupdb and create war" do
interpreter "bash"
cwd "#{node['home']['dir']}/open-lmis"
code <<-EOH
export PATH=$PATH:/home/openlmis/gradle-1.6/bin
gradle setupdb seed testseed war
EOH
user "openlmis"
end

execute "move war to home directory" do
	command "mv #{node['war']['location']}/openlmis-web.war ROOT.war"
	cwd "#{node['home']['dir']}"
	user "openlmis"
end

script "deploy war" do
interpreter "bash"
code <<-EOH 
service tomcat stop
rm -rf #{node['tomcat']['home']}/webapps/ROOT/
mkdir #{node['tomcat']['home']}/webapps/ROOT/
cd #{node['tomcat']['home']}/webapps/ROOT/
jar -xvf /home/openlmis/ROOT.war
sudo service tomcat start
EOH
user "openlmis"
end

script "move static contents to httpd directory" do
interpreter "bash"
cwd "#{node['tomcat']['home']}/webapps/ROOT"
code <<-EOH
rm -rf /var/www/openlmis
mkdir /var/www/openlmis
mv public/ /var/www/openlmis/
EOH
user "root"
end
