Description
===========
Installs htop for system analytics.

Requirements
============

Attributes
==========

Usage
=====

