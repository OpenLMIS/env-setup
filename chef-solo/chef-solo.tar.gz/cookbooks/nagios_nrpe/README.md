Description
===========
Installs and configures nrpe for Nagios monitoring and drops plugins
Requirements
============

Attributes
==========

Usage
=====

