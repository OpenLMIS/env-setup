# CHANGELOG for nagios_nrpe

This file is used to list changes made in each version of nagios_nrpe.

## 0.1.0:

* Initial release of nagios_nrpe

- - - 
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
