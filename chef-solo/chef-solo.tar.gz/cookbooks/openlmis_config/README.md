Description
===========
Drops openlmis related config into the openlmis user home
Requirements
============

Attributes
==========

Usage
=====

