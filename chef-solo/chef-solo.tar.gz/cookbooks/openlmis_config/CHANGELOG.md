# CHANGELOG for openlmis_config

This file is used to list changes made in each version of openlmis_config.

## 0.1.0:

* Initial release of openlmis_config

- - - 
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
