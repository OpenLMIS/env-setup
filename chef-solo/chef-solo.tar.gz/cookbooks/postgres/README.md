Description
===========
Cookbook for installation of Postgres 9.1.

Requirements
============

Attributes
==========

Usage
=====

