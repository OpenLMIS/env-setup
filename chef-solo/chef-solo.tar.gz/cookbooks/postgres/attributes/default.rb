node.set["postgreSQL"]={}
node.set["postgreSQL"]["allowSubnet"]=["192.168.34.0/24", "10.15.6.0/24"]
node.set["postgreSQL"]["archivedir"]='/var/lib/pgsql/9.1/archive'
node.set["postgreSQL"]["slaveSubnet"]=["54.251.253.0/23"]
node.set["postgreSQL"]["home"]='/var/lib/pgsql/9.1/'
