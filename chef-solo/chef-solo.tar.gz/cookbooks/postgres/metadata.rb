maintainer       "ThoughtWorks - DevOps Team | Pratima Singh, Vinay Mor"
maintainer_email "pratima@thoughtworks.com, vinaymor@thoughtworks.com"
license          "Eclipse Public License"
description      "Installs/Configures postgreSQL 9.1"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "1.0.0"
